"""ARISE web console.

A small Flask app that gives ARISE a face:

* **Drop FITS frames** (or a whole night as a ZIP, or even a plain PNG/JPG) on
  the page -> the full pipeline runs -> the HTML report + ranked candidates
  appear inline.
* **Run demo night** button -> synthesises the demo night (hidden asteroid,
  transient, variable) and reduces it, no data needed.
* **Ask ARISE** -- a retrieval assistant (see :mod:`arise.rag`) answering from
  the project docs, the research brief, and the latest run's own outputs.

Start with:  python -m arise.webapp   (default http://127.0.0.1:8770)
"""
from __future__ import annotations

import io
import re
import threading
import time
import uuid
import zipfile
from pathlib import Path

import numpy as np
from flask import Flask, jsonify, request, send_from_directory

from .config import PipelineConfig, INSTRUMENTS
from .logs import setup_logging, get_logger
from .rag import build_default_kb, KnowledgeBase

log = get_logger("webapp")

ROOT = Path(__file__).resolve().parent.parent          # project root (D:/ARISE)
WEB_DATA = ROOT / "data_web"
ASSETS = Path(__file__).resolve().parent / "assets"

app = Flask("arise")
_runs: dict[str, dict] = {}                            # run_id -> state
_kb_lock = threading.Lock()
_kb: KnowledgeBase | None = None

_FITS_EXT = (".fits", ".fit", ".fts", ".fz")
_IMG_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff")


# --------------------------------------------------------------------------- #
# knowledge base
# --------------------------------------------------------------------------- #
def _get_kb(rebuild: bool = False) -> KnowledgeBase:
    global _kb
    with _kb_lock:
        if _kb is None or rebuild:
            latest = sorted(WEB_DATA.glob("*"), key=lambda p: p.stat().st_mtime,
                            reverse=True) if WEB_DATA.exists() else []
            data_dirs = [latest[0]] if latest else [ROOT / "data"]
            _kb = build_default_kb(ROOT, data_dirs=data_dirs)
        return _kb


# --------------------------------------------------------------------------- #
# pipeline execution (background thread per run)
# --------------------------------------------------------------------------- #
def _image_to_fits(data: bytes, name: str, raw_dir: Path) -> Path:
    """Convert an ordinary image (PNG/JPG/...) to a light-frame FITS."""
    from astropy.io import fits
    import matplotlib.image as mpimg

    arr = mpimg.imread(io.BytesIO(data))
    if arr.ndim == 3:                       # RGB(A) -> luminance
        arr = arr[..., :3] @ np.array([0.299, 0.587, 0.114])
    arr = np.asarray(arr, dtype=np.float32)
    if arr.max() <= 1.5:                    # 0-1 float images -> counts-like scale
        arr = arr * 60000.0
    arr = np.flipud(arr)                    # image row order -> FITS row order
    hdr = fits.Header()
    hdr["IMAGETYP"] = "light"
    hdr["EXPTIME"] = 1.0
    hdr["FILTER"] = "NONE"
    hdr["OBJECT"] = Path(name).stem
    hdr["COMMENT"] = "converted from a plain image by ARISE web console"
    out = raw_dir / (Path(name).stem + ".fits")
    fits.PrimaryHDU(arr, hdr).writeto(out, overwrite=True)
    return out


def _launch_run(run_id: str, instrument: str, demo: bool, size: int = 512) -> None:
    state = _runs[run_id]
    base = WEB_DATA / run_id
    raw = base / "raw"

    def work():
        try:
            setup_logging("INFO", log_file=base / "reports" / "arise.log")
            if demo:
                state["message"] = "Generating synthetic night..."
                from .synth import generate_night, SynthConfig
                generate_night(raw, instrument,
                               SynthConfig(nx=size, ny=size, n_science=6))
            state["message"] = "Reducing frames..."
            cfg = PipelineConfig(instrument=instrument)
            cfg.log_level = "INFO"
            cfg.paths.raw = str(raw)
            cfg.paths.master = str(base / "master")
            cfg.paths.reduced = str(base / "reduced")
            cfg.paths.catalogs = str(base / "catalogs")
            cfg.paths.reports = str(base / "reports")
            from .pipeline import run_pipeline
            result = run_pipeline(cfg)

            d = result.discovery
            state.update({
                "state": "done",
                "message": "Complete",
                "report": f"/runs/{run_id}/reports/arise_report.html",
                "summary": {
                    "frames": result.n_science,
                    "movers": d.n_movers if d else 0,
                    "transients": d.n_transients if d else 0,
                    "variables": d.n_variables if d else 0,
                    "objects": d.n_objects if d else 0,
                },
            })
            _get_kb(rebuild=True)          # so Ask-ARISE knows this run
        except Exception as exc:
            log.error("Run %s failed: %s", run_id, exc, exc_info=True)
            state.update({"state": "error", "message": f"{exc}"})

    threading.Thread(target=work, daemon=True).start()


def _tail_log(run_id: str, lines: int = 12) -> list[str]:
    p = WEB_DATA / run_id / "reports" / "arise.log"
    if not p.exists():
        return []
    try:
        content = p.read_text(encoding="utf-8", errors="replace").splitlines()
        out = []
        for line in content[-lines:]:
            # strip "date level logger" prefix for compact display
            out.append(re.sub(r"^[\d\-]+ [\d:]+\s+\w+\s+\S+\s+", "", line))
        return out
    except Exception:
        return []


# --------------------------------------------------------------------------- #
# routes
# --------------------------------------------------------------------------- #
@app.get("/")
def index():
    return (ASSETS / "webapp.html").read_text(encoding="utf-8")


@app.get("/api/instruments")
def instruments():
    return jsonify([{"id": k, "label": v.telescope or k} for k, v in INSTRUMENTS.items()])


@app.post("/api/demo")
def demo():
    run_id = uuid.uuid4().hex[:10]
    instrument = request.json.get("instrument", "dfot_2kx2k") if request.is_json else "dfot_2kx2k"
    (WEB_DATA / run_id / "raw").mkdir(parents=True, exist_ok=True)
    _runs[run_id] = {"state": "running", "message": "Starting...", "t0": time.time()}
    _launch_run(run_id, instrument, demo=True)
    return jsonify({"run_id": run_id})


@app.post("/api/upload")
def upload():
    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "no files received"}), 400
    instrument = request.form.get("instrument", "generic")
    run_id = uuid.uuid4().hex[:10]
    raw = WEB_DATA / run_id / "raw"
    raw.mkdir(parents=True, exist_ok=True)

    n_fits = n_img = 0
    for f in files:
        name = Path(f.filename or "upload").name
        payload = f.read()
        low = name.lower()
        if low.endswith(".zip"):
            with zipfile.ZipFile(io.BytesIO(payload)) as z:
                for zn in z.namelist():
                    if zn.lower().endswith(_FITS_EXT):
                        (raw / Path(zn).name).write_bytes(z.read(zn))
                        n_fits += 1
        elif low.endswith(_FITS_EXT) or low.endswith(".fits.gz"):
            (raw / name).write_bytes(payload)
            n_fits += 1
        elif low.endswith(_IMG_EXT):
            _image_to_fits(payload, name, raw)
            n_img += 1

    if n_fits + n_img == 0:
        return jsonify({"error": "no FITS / image files found in the drop"}), 400

    _runs[run_id] = {"state": "running", "message": "Files received...",
                     "t0": time.time(),
                     "note": (f"{n_img} plain image(s) converted to FITS -- "
                              "extraction only, no sky coordinates" if n_img else "")}
    _launch_run(run_id, instrument, demo=False)
    return jsonify({"run_id": run_id, "n_fits": n_fits, "n_images": n_img})


@app.get("/api/status/<run_id>")
def status(run_id: str):
    state = _runs.get(run_id)
    if state is None:
        return jsonify({"error": "unknown run"}), 404
    out = dict(state)
    out["elapsed"] = round(time.time() - state.get("t0", time.time()), 1)
    out["log"] = _tail_log(run_id)
    return jsonify(out)


@app.get("/runs/<run_id>/<path:subpath>")
def run_files(run_id: str, subpath: str):
    return send_from_directory(WEB_DATA / run_id, subpath)


@app.post("/api/ask")
def ask():
    q = (request.json or {}).get("question", "").strip()
    if not q:
        return jsonify({"error": "empty question"}), 400
    return jsonify(_get_kb().answer(q))


@app.post("/api/kb/add")
def kb_add():
    url = (request.json or {}).get("url", "").strip()
    if not url.startswith(("http://", "https://")):
        return jsonify({"error": "provide an http(s) URL"}), 400
    n = _get_kb().add_url(url)
    # persist so it survives restarts
    kb_dir = ROOT / "kb"
    kb_dir.mkdir(exist_ok=True)
    urls_file = kb_dir / "urls.txt"
    existing = urls_file.read_text(encoding="utf-8") if urls_file.exists() else ""
    if url not in existing:
        with open(urls_file, "a", encoding="utf-8") as fh:
            fh.write(url + "\n")
    return jsonify({"ok": n > 0, "chunks": n})


def main(host: str = "127.0.0.1", port: int = 8770) -> None:
    setup_logging("INFO")
    from .keys import load_keys
    load_keys(ROOT)
    WEB_DATA.mkdir(exist_ok=True)
    _get_kb()                              # warm the knowledge base
    log.info("ARISE web console on http://%s:%d", host, port)
    app.run(host=host, port=port, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
